package com.VentasTienda.cl.VentasTienda.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table (name= "Trabajador")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Trabajador {

    // Atributos.
    @Id
    @Column (length = 13)
    private Long run;

    @Column (nullable = false)
    private char dv;

    @Column (length = 100, nullable = false)
    private String nombre_completo;

    @Column (length = 15, nullable = false)
    private Long sueldoBase;

    @Column (nullable = false)
    private String horario_de_trabajo;
}
