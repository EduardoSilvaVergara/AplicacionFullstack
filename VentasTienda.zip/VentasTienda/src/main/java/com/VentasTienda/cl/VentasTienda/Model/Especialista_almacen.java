package com.VentasTienda.cl.VentasTienda.Model;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;


@Entity
@AllArgsConstructor
public class Especialista_almacen extends Trabajador{

}
