package com.VentasTienda.cl.VentasTienda.Model;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;


@Entity
@AllArgsConstructor
public class Atencion_al_cliente extends Trabajador{

    // Atributos.

}
