package com.VentasTienda.cl.VentasTienda.Service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.VentasTienda.cl.VentasTienda.Model.Inventario;
import com.VentasTienda.cl.VentasTienda.Model.Tienda;
import com.VentasTienda.cl.VentasTienda.Model.Venta;
import com.VentasTienda.cl.VentasTienda.Repository.InventarioRepository;
import com.VentasTienda.cl.VentasTienda.Repository.TiendaRepository;
import com.VentasTienda.cl.VentasTienda.Repository.VentaRepository;

import jakarta.transaction.Transactional;


@Service
@Transactional
public class ReporteService {

    @Autowired
    private InventarioRepository inventarioRepository;

    @Autowired
    private TiendaRepository tiendaRepository;

    @Autowired
    private VentaRepository ventaRepository;

    public String reporteVentas() {
        List<Venta> listaVenta = ventaRepository.findAll();
        String textVenta = "Reporte de Ventas: \n";
        int totalGanado = 0;

        for (Venta v : listaVenta) {
            textVenta += "Venta N°" + v.getNro_identificador()
                    + " | Producto: " + v.getProducto().getNombre()
                    + " | Cantidad: " + v.getCantidad()
                    + " | Total: " + v.getTotal()
                    + " | Fecha: " + v.getFecha() + "\n";
                totalGanado += v.getTotal();
        }
        textVenta += "\n Total Ganado: $" + totalGanado;
        return textVenta;
    }

    public String reporteTiendas() {
        List<Tienda> listaTienda = tiendaRepository.findAll();
        String textTienda = "Reporte de Tienda: \n";

        for (Tienda t : listaTienda) {
            textTienda += "Tienda ID: " + t.getNro_identificador()
                    + " | Direccion: " + t.getDireccion()
                    + " | Horario: " + t.getHorario_atencion()
                    + " | Trabajadores: " + t.getTrabajadores().size() + "\n";  
        }
        return textTienda;
    }

    public String reporteInventario() {
       List<Inventario> listaInventario = inventarioRepository.findAll();
       String textInventario = "Reporte de Inventario: \n";

    for (Inventario i : listaInventario) {
        textInventario += "Inventario N°" + i.getNro_identificador()
                    + " | Productos: " + i.getLista_productos().size()
                    + " | Administrador: " + i.getAdministrador() + "\n";
        }
       return textInventario;
    }



}
