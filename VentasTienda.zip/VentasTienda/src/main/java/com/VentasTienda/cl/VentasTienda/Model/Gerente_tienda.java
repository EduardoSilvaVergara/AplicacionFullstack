package com.VentasTienda.cl.VentasTienda.Model;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;


@Entity
@AllArgsConstructor
public class Gerente_tienda extends Trabajador{

}
