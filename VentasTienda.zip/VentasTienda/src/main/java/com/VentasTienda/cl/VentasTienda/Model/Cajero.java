package com.VentasTienda.cl.VentasTienda.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Cajero extends Trabajador{

    // Atributos.
    @Column (length = 30, nullable = true)
    private String caja;
    
}
