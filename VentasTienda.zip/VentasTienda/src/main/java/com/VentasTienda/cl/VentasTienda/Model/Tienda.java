package com.VentasTienda.cl.VentasTienda.Model;

import java.util.ArrayList;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table (name = "Tienda")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Tienda {

    // Atributos.
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    @Column (length = 15)
    private Long nro_identificador;

    @Column (length = 70, nullable = false)
    private String direccion;

    @Column (nullable = false)
    private String horario_atencion;

    @OneToOne
    @JoinColumn (name = "run")
    private Gerente_tienda gerente;

    @Column (nullable = false)
    private ArrayList<Trabajador> trabajadores;

    @OneToOne
    @JoinColumn (name = "nro_identificador")
    private Inventario inventario;
}
