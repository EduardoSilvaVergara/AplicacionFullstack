package com.VentasTienda.cl.VentasTienda.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Venta")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Venta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (length = 10)
    private Long nro_identificador;
    @ManyToOne
    @Column (name = "nro_identificador",nullable = false)
    private Producto producto;

    @Column (length = 5, nullable = false)
    private int cantidad;

    @Column (length = 10, nullable = false)
    private long total;

    @Column (length = 30, nullable = false)
    private String fecha;

}
