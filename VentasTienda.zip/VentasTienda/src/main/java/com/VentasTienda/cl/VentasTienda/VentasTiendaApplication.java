package com.VentasTienda.cl.VentasTienda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VentasTiendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VentasTiendaApplication.class, args);
	}

}
