package com.VentasTienda.cl.VentasTienda.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.VentasTienda.cl.VentasTienda.Service.ReporteService;

@RestController
@RequestMapping("api/v1/reportes")
public class ReporteController {
    
    @Autowired
    private ReporteService reporteService;

    public ResponseEntity<> generarReporteVentas() {
        
    }







}
